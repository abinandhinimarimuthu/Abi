cconst express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();
app.use(bodyParser.json());

// Set up Shiprocket API credentials
const API_KEY = process.env.SHIPROCKET_API_KEY;
const SECRET_KEY = process.env.SHIPROCKET_SECRET_KEY;
const BASE_URL = process.env.SHIPROCKET_BASE_URL;

// Helper function to make API calls
const makeShiprocketRequest = async (endpoint, method, data = {}) => {
  try {
    const config = {
      headers: {
        'Authorization': `Bearer ${API_KEY}:${SECRET_KEY}`,
      },
    };

    const response = await axios({
      method: method,
      url: `${BASE_URL}${endpoint}`,
      data: data,
      ...config,
    });

    return response.data;
  } catch (error) {
    console.error('Error in Shiprocket API request:', error);
    throw new Error('Error in Shiprocket API request');
  }
};

// Example Route: Create an order
app.post('/shiprocket/create-order', async (req, res) => {
  const { orderData } = req.body;

  try {
    const result = await makeShiprocketRequest('/orders/create', 'POST', orderData);
    res.status(200).json({
      success: true,
      message: 'Order created successfully',
      data: result,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error creating order',
      error: error.message,
    });
  }
});

// Example Route: Track a shipment
app.get('/shiprocket/track/:trackingNumber', async (req, res) => {
  const { trackingNumber } = req.params;

  try {
    const result = await makeShiprocketRequest(`/orders/track/${trackingNumber}`, 'GET');
    res.status(200).json({
      success: true,
      message: 'Shipment tracked successfully',
      data: result,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error tracking shipment',
      error: error.message,
    });
  }
});

// Example Route: Get available couriers
app.get('/shiprocket/couriers', async (req, res) => {
  try {
    const result = await makeShiprocketRequest('/couriers', 'GET');
    res.status(200).json({
      success: true,
      message: 'Courier list fetched successfully',
      data: result,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching couriers',
      error: error.message,
    });
  }
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
