const mongoose = require('mongoose');

const couponSchema = new mongoose.Schema({
  code: {
    type: String,
    required: true,
    unique: true
  },
  discountPercentage: {
    type: Number,
    required: true,
    min: 0,  // Ensures no negative discount percentage
    max: 100 // Ensures no discount percentage greater than 100
  },
  freeShipping: {
    type: Boolean,
    default: false // Whether the coupon gives free shipping
  },
  validFrom: {
    type: Date,
    required: true
  },
  validUntil: {
    type: Date,
    required: true
  },
  minOrderValue: {
    type: Number,
    default: 0 // Minimum order value for the coupon to be valid (optional)
  }
});

const Coupon = mongoose.model('Coupon', couponSchema);

module.exports = Coupon;
