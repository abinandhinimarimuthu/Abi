const mongoose = require('mongoose');

const cartSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,  // Use ObjectId for user reference
    ref: 'User', // Reference to the User model
    required: true
  },
  productsInCart: [{
    productId: {
      type: mongoose.Schema.Types.ObjectId,  // Use ObjectId for product reference
      ref: 'Product', // Reference to the Product model
      required: true
    },
    productQty: {
      type: Number,
      required: true,
      min: 1 // Ensures quantity is at least 1
    },
    price: {  // Store the price of the product at the time of adding to cart
      type: Number,
      required: true
    }
  }],
  coupon: {  // Optional coupon applied to the cart
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Coupon',
    default: null
  },
  totalAmount: {  // Total amount of the cart, including discounts
    type: Number,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Middleware to update totalAmount before saving
cartSchema.pre('save', function(next) {
  if (this.productsInCart.length > 0) {
    let total = 0;
    this.productsInCart.forEach(item => {
      total += item.productQty * item.price;
    });

    if (this.coupon) {
      // Apply discount if a coupon is applied
      // Assuming coupon.discountPercentage exists and is a valid number
      const discount = this.coupon.discountPercentage || 0;
      total = total - (total * discount / 100);
    }

    this.totalAmount = total;
  }
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Cart', cartSchema);
