import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import CartItems from "../../components/user/cart/Cartitems";
import RecentlyViewed from "../../components/user/cart/recentlyviewed";
import { faArrowLeft } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Navbar from "../../components/user/navbar/navbar";
import { Helmet } from "react-helmet";

const ShoppingCartPage = () => {
  const [totalAmount, setTotalAmount] = useState(0); // State to hold the total amount
  const [freeDeliveryEligible, setFreeDeliveryEligible] = useState(false); // State to track eligibility for free delivery
  const [discountEligible, setDiscountEligible] = useState(false); // State to track eligibility for discount

  useEffect(() => {
    // This is where you would calculate the total cart value
    // For now, I'm just using a hardcoded totalAmount for demonstration
    const cartTotal = 550; // Hardcoded example value, replace with actual cart total calculation logic
    setTotalAmount(cartTotal);

    // Check for Free Delivery and Discount eligibility
    if (cartTotal >= 499) {
      setFreeDeliveryEligible(true);
      setDiscountEligible(true);
    } else {
      setFreeDeliveryEligible(false);
      setDiscountEligible(false);
    }
  }, [totalAmount]);

  return (
    <div className="bg-pink-50 min-h-screen">
      <Helmet>
        <title>Shopping Cart | Mera Bestie</title>
      </Helmet>
      <Navbar />

      <div className="container mx-auto px-4 py-8 space-y-6 mt-16">
        <div className="bg-white shadow-md rounded-lg">
          <div className="p-4 flex flex-col md:flex-row items-center justify-between">
            <h1 className="text-2xl font-bold text-gray-800">Shopping Cart</h1>
            <Link
              to="/shop"
              className="flex items-center space-x-2 text-pink-600 hover:text-pink-800 transition-colors mt-4 md:mt-0"
            >
              <FontAwesomeIcon icon={faArrowLeft} className="mr-2" />
              Continue Shopping
            </Link>
          </div>
        </div>

        {/* Content Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 overflow-auto">
          <CartItems />
          <RecentlyViewed />
        </div>

        {/* Promotional Offers Section */}
        <div className="bg-white shadow-md rounded-lg p-4 mt-6">
          <h2 className="text-xl font-semibold text-gray-800">Promotions</h2>
          <div className="mt-4">
            {freeDeliveryEligible && (
              <p className="text-green-600">Free Delivery for Orders Above ₹499</p>
            )}
            {discountEligible && (
              <p className="text-green-600">10% Off on Orders Above ₹499</p>
            )}
            {!freeDeliveryEligible && !discountEligible && (
              <p className="text-red-600">No promotions available for this order.</p>
            )}
          </div>
        </div>

        {/* Total Amount Section */}
        <div className="bg-white shadow-md rounded-lg p-4 mt-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-gray-800">Total Amount</h3>
            <p className="text-xl font-bold text-gray-900">₹{totalAmount}</p>
          </div>
          <div className="mt-4 flex justify-between items-center">
            {discountEligible && (
              <p className="text-green-600">10% Discount Applied!</p>
            )}
            {freeDeliveryEligible && (
              <p className="text-green-600">Free Delivery Included!</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShoppingCartPage;
