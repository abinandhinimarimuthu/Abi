import React, { useState } from 'react';

const Signup = () => {
  const [email, setEmail] = useState('');
  const [isVerified, setIsVerified] = useState(false);

  const handleSendVerification = async () => {
    try {
      const response = await fetch('/api/auth/verify-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const result = await response.json();
      alert(result.message);
    } catch (error) {
      console.error('Error sending verification email:', error);
    }
  };

  return (
    <div>
      <h2>Signup</h2>
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      {!isVerified && <button onClick={handleSendVerification}>Verify Email</button>}
      {isVerified && <p>Email Verified!</p>}
    </div>
  );
};

export default Signup;

