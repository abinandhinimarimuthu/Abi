import React, { useState, useEffect } from 'react';
import Sidebar from '../../components/admin/sidebar';
import { Pencil, Save, Search, ArrowUpDown, Trash } from 'lucide-react';
import { Helmet } from "react-helmet";
import { useParams, useNavigate } from 'react-router-dom';

const Product = () => {
  const { sellerId } = useParams();
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [editValues, setEditValues] = useState({
    name: '',
    category: '',
    price: '',
    inStockValue: '',
    soldStockValue: '',
    description: '',
    images: []
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchExpanded, setIsSearchExpanded] = useState(false);
  const [sortConfig, setSortConfig] = useState({
    key: null,
    direction: 'ascending'
  });
  const [newProduct, setNewProduct] = useState({
    name: '',
    category: '',
    price: '',
    inStockValue: '',
    soldStockValue: '',
    description: '',
    images: []
  });
  const [loading, setLoading] = useState(false); // Loading state for Add/Remove operations

  // Verify seller and fetch products
  useEffect(() => {
    const verifySeller = async () => {
      if (!sellerId) {
        navigate('/seller/login');
        return;
      }

      try {
        const response = await fetch('https://ecommercebackend-8gx8.onrender.com/admin/verify-seller', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ sellerId }),
        });

        const data = await response.json();
        if (data.loggedIn !== 'loggedin') {
          navigate('/seller/login');
        }
      } catch (error) {
        console.error('Error verifying seller:', error);
        navigate('/seller/login');
      }
    };

    verifySeller();
    fetchProducts();
  }, [sellerId, navigate]);

  const fetchProducts = async () => {
    try {
      const response = await fetch('https://ecommercebackend-8gx8.onrender.com/get-product');
      const data = await response.json();
      setProducts(data.products || []); // Default to an empty array if no products are found
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const handleAddProduct = async () => {
    setLoading(true);
    const formData = new FormData();
    formData.append('name', newProduct.name);
    formData.append('category', newProduct.category);
    formData.append('price', newProduct.price);
    formData.append('inStockValue', newProduct.inStockValue);
    formData.append('soldStockValue', newProduct.soldStockValue);
    formData.append('description', newProduct.description);

    // Append the images to the form data
    Array.from(newProduct.images).forEach((image) => {
      formData.append('images', image);
    });

    try {
      const response = await fetch('https://ecommercebackend-8gx8.onrender.com/add-product', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        alert('Product added successfully');
        fetchProducts();
        setNewProduct({ name: '', category: '', price: '', inStockValue: '', soldStockValue: '', description: '', images: [] });
      } else {
        alert('Error adding product');
      }
    } catch (error) {
      console.error('Error adding product:', error);
      alert('Failed to add product');
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveProduct = async (productId) => {
    if (window.confirm('Are you sure you want to remove this product?')) {
      setLoading(true);
      try {
        const response = await fetch(`https://ecommercebackend-8gx8.onrender.com/remove-product/${productId}`, {
          method: 'DELETE',
        });

        if (response.ok) {
          setProducts(products.filter((product) => product.productId !== productId)); // Remove product from list
          alert('Product removed successfully');
        } else {
          alert('Error removing product');
        }
      } catch (error) {
        console.error('Error removing product:', error);
        alert('Failed to remove product');
      } finally {
        setLoading(false);
      }
    }
  };

  // Handle product edit
  const handleEdit = (product) => {
    setEditingId(product.productId);
    setEditValues({
      name: product.name || '',
      category: product.category || '',
      price: product.price || 0,
      inStockValue: product.inStockValue || 0,
      soldStockValue: product.soldStockValue || 0,
      description: product.description || '',
      images: product.images || []
    });
  };

  // Handle save after editing
  const handleSave = async (productId) => {
    try {
      const response = await fetch('https://ecommercebackend-8gx8.onrender.com/instock-update', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          productId,
          name: editValues.name,
          category: editValues.category,
          price: editValues.price,
          inStockValue: editValues.inStockValue,
          soldStockValue: editValues.soldStockValue,
          description: editValues.description,
        }),
      });

      if (response.ok) {
        setEditingId(null);
        fetchProducts();
      }
    } catch (error) {
      console.error('Error updating product:', error);
    }
  };

  // Handle sorting
  const handleSort = (key) => {
    let direction = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  const sortedProducts = React.useMemo(() => {
    if (!Array.isArray(products)) return [];
    let sortableProducts = [...products];
    if (sortConfig.key !== null) {
      sortableProducts.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'ascending' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'ascending' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableProducts;
  }, [products, sortConfig]);

  const filteredProducts = sortedProducts.filter((product) =>
    product.productId?.toString().toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex">
      <Helmet>
        <title>Products | Admin | Mera Bestie</title>
      </Helmet>
      <Sidebar />
      <div className="flex-1 p-8 ml-[5rem] lg:ml-64 bg-pink-50 min-h-screen">
        <div className="mb-6 flex justify-between items-center">
          <div className="relative">
            <div className={`flex items-center ${isSearchExpanded ? 'w-full md:w-64' : 'w-10 md:w-64'} transition-all duration-300`}>
              <button
                className="md:hidden absolute left-2 z-10"
                onClick={() => setIsSearchExpanded(!isSearchExpanded)}
              >
                <Search size={20} />
              </button>
              <input
                type="text"
                placeholder="Search by product ID or name..."
                className={`pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-300 ${isSearchExpanded ? 'w-full opacity-100' : 'w-0 md:w-full opacity-0 md:opacity-100'} transition-all duration-300`}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Add Product Form */}
        <div className="mb-6 bg-white p-4 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold">Add Product</h2>
          <div className="space-y-4">
            <input
              type="text"
              placeholder="Product Name"
              value={newProduct.name}
              onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
              className="w-full p-2 border rounded"
            />
            <input
              type="text"
              placeholder="Category"
              value={newProduct.category}
              onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
              className="w-full p-2 border rounded"
            />
            <input
              type="number"
              placeholder="Price"
              value={newProduct.price}
              onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
              className="w-full p-2 border rounded"
            />
            <input
              type="number"
              placeholder="In Stock"
              value={newProduct.inStockValue}
              onChange={(e) => setNewProduct({ ...newProduct, inStockValue: e.target.value })}
              className="w-full p-2 border rounded"
            />
            <input
              type="number"
              placeholder="Sold Stock"
              value={newProduct.soldStockValue}
              onChange={(e) => setNewProduct({ ...newProduct, soldStockValue: e.target.value })}
              className="w-full p-2 border rounded"
            />
            <textarea
              placeholder="Product Description"
              value={newProduct.description}
              onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
              className="w-full p-2 border rounded"
            />
            <input
              type="file"
              multiple
              onChange={(e) => setNewProduct({ ...newProduct, images: e.target.files })}
              className="w-full p-2 border rounded"
            />
            <button
              onClick={handleAddProduct}
              className="w-full p-2 bg-blue-500 text-white rounded"
              disabled={loading}
            >
              {loading ? 'Adding...' : 'Add Product'}
            </button>
          </div>
        </div>

        {/* Product Table */}
        <div className="bg-white rounded-lg shadow-md overflow-x-auto">
          <table className="min-w-full table-auto">
            <thead className="bg-pink-100">
              <tr>
                {['Product', 'Category', 'Price', 'In Stock', 'Sold'].map((key, index) => (
                  <th
                    key={index}
                    className="px-4 py-2 cursor-pointer"
                    onClick={() => handleSort(key.toLowerCase().replace(' ', ''))}
                  >
                    {key}
                    <ArrowUpDown size={16} className="inline ml-1" />
                  </th>
                ))}
                <th className="px-4 py-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredProducts.map((product) => (
                <tr key={product.productId}>
                  <td className="px-4 py-2">{product.name}</td>
                  <td className="px-4 py-2">{product.category}</td>
                  <td className="px-4 py-2">{product.price}</td>
                  <td className="px-4 py-2">{product.inStockValue}</td>
                  <td className="px-4 py-2">{product.soldStockValue}</td>
                  <td className="px-4 py-2">
                    <div className="flex justify-evenly">
                      <button
                        onClick={() => handleEdit(product)}
                        className="text-blue-500 hover:text-blue-700"
                      >
                        <Pencil size={16} />
                      </button>
                      <button
                        onClick={() => handleRemoveProduct(product.productId)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Product;
