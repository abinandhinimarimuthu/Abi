import AdminLogin from "../../components/admin/login";

const LoginPage = () => {
  return <AdminLogin />;
};

export default LoginPage;
